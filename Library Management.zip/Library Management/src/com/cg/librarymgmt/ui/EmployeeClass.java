public class EmployeeClass {
	int empId;
	String empName;
	
	public void getDetails(int Id, String Name)
	{
		empId = Id;
		empName = Name;
	}
	
	public void displayDetails()
	{
		System.out.println("Employee Id is "+empId);
		System.out.println("Employee name is "+empName);
	}
	public static void main(String args[])
	{
		EmployeeClass e = new EmployeeClass();
		e.getDetails(751, "Priya");
		e.displayDetails();
	}
	
	

}  


	